//
//  NSObject+FMDBCategory.h
//  DBDemod
//
//  Created by hzjava-imac on 2017/3/3.
//  Copyright © 2017年 hzjava-imac. All rights reserved.
//

#import <Foundation/Foundation.h>

# define DBPath @"area.db"
@interface NSObject (FMDBCategory)

/**
    创建表

 @param tableName 表名
 @param fields 字段名
 @return 是否创建成功
 */
-(BOOL)creatTable:(NSString *)tableName andFields:(NSArray*)fields;
/**
 写入数据（如果包含新的字段名，表中会增加相应的字段）
 
 @param tableName 写入数据的表名
 @param dataDic 写入的数据
 */
- (BOOL)insertTable:(NSString *)tableName andDataSource:(NSDictionary*)dataDic;
/**
 删除数据
 
 @param tableName 要查的表名
 @param keys 条件字段
 @param values 条件值
 */
- (BOOL)deleteData:(NSString*)tableName WithConditionKey:(NSArray<NSString*>*)keys AndValue:(NSArray<NSString*>*)values;
/**
 更新数据
 
 @param tableName 表名
 @param conditionKeys 条件字段
 @param conditionValues 条件字段值
 @param setKeys 更新的数据的字段
 @param setValues 更新的数据的值
 */
- (BOOL)updateData:(NSString*)tableName WithConditionKey:(NSArray<NSString*>*)conditionKeys AndValue:(NSArray<NSString*>*)conditionValues withSetKey:(NSArray<NSString*>*)setKeys andValue:(NSArray<NSString*>*)setValues;
/**
 查找
 @param tableName 要查的表名
 @param key 要查的字段
 @param value 要查的字段名
 @return 返回数组（元素为字典类型）
 */
- (NSArray*)findData:(NSString*)tableName WithConditionKey:(NSString*)key AndValue:(NSString*)value;
@end
