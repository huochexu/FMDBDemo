//
//  ViewController.m
//  DBDemod
//
//  Created by hzjava-imac on 2017/3/3.
//  Copyright © 2017年 hzjava-imac. All rights reserved.
//

#import "ViewController.h"
#import "NSObject+FMDBCategory.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //创建表
    [self creatTable:@"test1" andFields:@[@"field1",@"field2",@"field3"]];
    
    //增加数据
    NSMutableDictionary *paramMuDic = [NSMutableDictionary dictionary];
    paramMuDic[@"field1"] = @"2222";
    paramMuDic[@"field2"] = @"aaaaa21";
    paramMuDic[@"field10"] = @"aaaaa32";
    [self insertTable:@"test1" andDataSource:paramMuDic];
    
    //查找
   NSArray *resultArray = [self findData:@"test1" WithConditionKey:@"field1" AndValue:@"2222"];
    
    //更新数据
    [self updateData:@"test1" WithConditionKey:@[@"field1",@"field2"] AndValue:@[@"2222",@"aaaaa21"] withSetKey:@[@"field13",@"field4"] andValue:@[@"aaaaaa",@"aaaaaa"]];

   //删除指定数据
    [self deleteData:@"test1" WithConditionKey:@[@"field1",@"field2"] AndValue:@[@"2222",@"aaaaa21"]];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
