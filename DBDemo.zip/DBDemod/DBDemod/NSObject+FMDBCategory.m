//
//  NSObject+FMDBCategory.m
//  DBDemod
//
//  Created by hzjava-imac on 2017/3/3.
//  Copyright © 2017年 hzjava-imac. All rights reserved.
//

#import "NSObject+FMDBCategory.h"
#import "FMDB.h"

@implementation NSObject (FMDBCategory)
/**
 创建数据表
 
 @param tableName 创建的数据表名
 @param fields 表中所需要包含的字段
 */
-(BOOL)creatTable:(NSString *)tableName andFields:(NSArray*)fields
{
    if (tableName == nil||tableName.length == 0) {
        NSLog(@"表名不能为空");
        return NO;
    }
    if (fields == nil||fields.count == 0) {
        NSLog(@"表字段不能为空");
        return NO;
    }
    for (id str in fields) {
        if (![str isKindOfClass:[NSString class]]) {
            NSLog(@"表字段只能为NSString类型");
            return NO;
        }
    }
    
    BOOL isOpen = [self open];
    if (isOpen) {
       BOOL result = [self creatFMDBTable:tableName andFields:fields];
        [self close];
        return result;
    }
    
    return NO;
}
/**
  写入数据（如果包含新的字段名，表中会增加相应的字段）

 @param tableName 写入数据的表名
 @param dataDic 写入的数据
 */
- (BOOL)insertTable:(NSString *)tableName andDataSource:(NSDictionary*)dataDic
{
    if (tableName == nil||tableName.length == 0) {
        NSLog(@"表名不能为空");
        return NO;
    }
    if (![dataDic isKindOfClass:[NSDictionary class]]) {
        NSLog(@"传入数据类型不为字典");
        return NO;
   
    }
    if (dataDic.count == 0) {
        NSLog(@"传入数据为空");
        return NO;
    }

   
    BOOL isOpen = [self open];
    if (isOpen) {
        
        BOOL result = [self insertFMDBTable:tableName andData:dataDic];
        [self close];
        return result;
    }
    return NO;
}

/**
   删除数据

 @param tableName 要查的表名
 @param keys 条件字段
 @param values 条件值
 */
- (BOOL)deleteData:(NSString*)tableName WithConditionKey:(NSArray<NSString*>*)keys AndValue:(NSArray<NSString*>*)values
{
    if (tableName == nil||tableName.length == 0) {
        NSLog(@"表名不能为空");
        return NO;
    }
    
    if (![keys isKindOfClass:[NSArray class]]) {
        NSLog(@"keys必须为数组");
        return NO;
    }
    if (![values isKindOfClass:[NSArray class]]) {
        NSLog(@"values必须为数组");
        return NO;
    }
    if (keys.count != values.count) {
        NSLog(@"keys与values个数必须一致");
        return NO;
    }
    
    BOOL isOpen = [self open];
    if (isOpen) {
        
       BOOL result = [self deleteFMDBData:tableName WithConditionKey:keys AndValue:values];
        [self close];
        return result;
    }
    return NO;
}

/**
   更新数据

 @param tableName 表名
 @param conditionKeys 条件字段
 @param conditionValues 条件字段值
 @param setKeys 更新的数据的字段
 @param setValues 更新的数据的值
 */
- (BOOL)updateData:(NSString*)tableName WithConditionKey:(NSArray<NSString*>*)conditionKeys AndValue:(NSArray<NSString*>*)conditionValues withSetKey:(NSArray<NSString*>*)setKeys andValue:(NSArray<NSString*>*)setValues
{
    if (tableName == nil||tableName.length == 0) {
        NSLog(@"表名不能为空");
        return NO;
    }
    
    if (![conditionKeys isKindOfClass:[NSArray class]]) {
        NSLog(@"conditionKeys必须为数组");
        return NO;
    }
    if (![conditionValues isKindOfClass:[NSArray class]]) {
        NSLog(@"conditionValues必须为数组");
        return NO;
    }
    if (![setKeys isKindOfClass:[NSArray class]]) {
        NSLog(@"setKeys必须为数组");
        return NO;
    }
    if (![setValues isKindOfClass:[NSArray class]]) {
        NSLog(@"setValues必须为数组");
        return NO;
    }
    if (conditionKeys.count != conditionValues.count) {
        NSLog(@"conditionKeys与conditionValues个数必须一致");
        return NO;
    }
    if (setKeys.count != setValues.count) {
        NSLog(@"setKeys与setValues个数必须一致");
        return NO;
    }
    
    BOOL isOpen = [self open];
    if (isOpen) {
        
      BOOL result =  [self updateFMDBData:tableName WithConditionKey:conditionKeys AndValue:conditionValues withSetKey:setKeys andValue:setValues];
        [self close];
        return result;
    }
    return NO;
}
/**
    查找
 @param tableName 要查的表名
 @param key 要查的字段
 @param value 要查的字段名
 @return 返回数组（元素为字典类型）
 */
- (NSArray*)findData:(NSString*)tableName WithConditionKey:(NSString*)key AndValue:(NSString*)value
{
    
    if (tableName == nil||tableName.length == 0) {
        NSLog(@"表名不能为空");
        return nil;
    }
    if (![key isKindOfClass:[NSString class]]) {
        NSLog(@"传入数据类型只能为NSStrin");
        return nil;
        
    }
    if (![value isKindOfClass:[NSString class]]) {
        NSLog(@"传入数据类型只能为NSStrin");
        return nil;
    }
    
    
    NSArray *resultArray = nil;
    if ([self open]) {
        
        resultArray = [self findFMDBData:tableName WithConditionKey:key AndValue:value];
        [self close];
    }
    return resultArray;
}

#pragma mark -
#pragma mark - fmdb三方
//创建表
//code text,pinyin text,cityName text
-(BOOL) creatFMDBTable:(NSString *)tableName andFields:(NSArray*)fields
{
     FMDatabase *fmdb = [self instancetFMDB];
    NSString *field = @"";
    for (int i=0;i<fields.count;i++) {
        
        NSString *str = [fields[i] lowercaseString];
        field = [field stringByAppendingString:str];
        if (fields.count-1 == i) {
            field = [field stringByAppendingString:@" text"];
        }else{
            field = [field stringByAppendingString:@" text,"];
        }
    }
    NSString *sql = [NSString stringWithFormat:@"create table if not exists %@(%@);",[tableName lowercaseString],field];
    BOOL result = [fmdb executeUpdate:sql];
    if (result) {
        
        NSLog(@"%@表创建成功",tableName);
    }else{
       NSLog(@"%@表创建失败",tableName);
    }
    
    return result;
}

//新增数据
//insert into test1(field3,field2,field1) values('efgdfgd','2sfdgsfd222','fdfsd');

- (BOOL)insertFMDBTable:(NSString *)tableName andData:(NSDictionary*)dataDic
{
    FMDatabase *fmdb = [self instancetFMDB];
    NSArray *keys = dataDic.allKeys;
    if (![self checkCondition:fmdb andTableName:tableName andCondition:keys]) {
        NSLog(@"字段检查出错");
        return NO;
    }
    
    //写入数据
    NSArray *objs = dataDic.allValues;
    
    NSString *keyStr = [keys componentsJoinedByString:@","];
    NSString *objStr = @"";
    for (int i = 0;i<objs.count;i++) {
        
        NSString *obj = objs[i];
        objStr = [NSString stringWithFormat:@"%@'%@'",objStr,obj];
        if (i<objs.count-1) {
            objStr = [objStr stringByAppendingString:@","];
        }
    }
    
    
    NSString *sql = [NSString stringWithFormat:@"insert into %@(%@) values(%@);",[tableName lowercaseString],keyStr,objStr];
    BOOL isWrite =[fmdb executeUpdate:sql];
    if (isWrite) {
        return YES;
        
    }else{
        NSLog(@"数据写入有误");
        return NO;
    }
   
}
//删除数据
//delete from test1 where field1='2222' and field2='aaaaa21';
- (BOOL)deleteFMDBData:(NSString*)tableName WithConditionKey:(NSArray<NSString*>*)keys AndValue:(NSArray<NSString*>*)values
{
    NSString *conditionStr = @"";
    for (int i = 0;i<values.count;i++) {
        
        NSString *obj = values[i];
        NSString *key = keys[i];
        conditionStr = [NSString stringWithFormat:@"%@%@='%@'",conditionStr,key,obj];
        if (i<values.count-1) {
            conditionStr = [conditionStr stringByAppendingString:@" and "];
        }
    }
    
    FMDatabase *fmdb = [self instancetFMDB];
    NSString *sqlStr = [NSString stringWithFormat:@"delete from %@ where %@;",tableName,conditionStr];
   BOOL isSuccess = [fmdb executeUpdate:sqlStr];
    if (!isSuccess) {
        NSLog(@"删除出错");
    }
    
    return isSuccess;
}
//修改
//update test1 set field3='aaaaaa',field4='aaaaaa' where field1='2222' and field2='aaaaa21'
- (BOOL)updateFMDBData:(NSString*)tableName WithConditionKey:(NSArray<NSString*>*)conditionKeys AndValue:(NSArray<NSString*>*)conditionValues withSetKey:(NSArray<NSString*>*)setKeys andValue:(NSArray<NSString*>*)setValues
{
    FMDatabase *fmdb = [self instancetFMDB];
    NSString *conditionStr = @"";
    for (int i = 0;i<conditionKeys.count;i++) {
        
        NSString *obj = conditionValues[i];
        NSString *key = conditionKeys[i];
        if (![fmdb columnExists:key inTableWithName:tableName]){
            NSLog(@"%@表中不存在%@字段",tableName,key);
            return NO;
        }
        conditionStr = [NSString stringWithFormat:@"%@%@='%@'",conditionStr,key,obj];
        if (i<conditionKeys.count-1) {
            conditionStr = [conditionStr stringByAppendingString:@" and "];
        }
    }
    
    NSString *setStr = @"";
    for (int i = 0;i<setKeys.count;i++) {
        
        NSString *obj = setValues[i];
        NSString *key = setKeys[i];
        setStr = [NSString stringWithFormat:@"%@%@='%@'",setStr,key,obj];
        if (i<conditionKeys.count-1) {
            setStr = [setStr stringByAppendingString:@","];
        }
    }
    if (![self checkCondition:fmdb andTableName:tableName andCondition:setKeys]) {
        NSLog(@"检查字段操作出错");
        return NO;
    }
    
    
    NSString *sqlStr = [NSString stringWithFormat:@"update %@ set %@ where %@",tableName,setStr,conditionStr];
    BOOL isSuccess = [fmdb executeUpdate:sqlStr];
    if (!isSuccess) {
        NSLog(@"修改出错");
    }
    return isSuccess;

}
//查找数据
//select * from test1 where field1='2222'
- (NSArray*)findFMDBData:(NSString*)tableName WithConditionKey:(NSString*)key AndValue:(NSString*)value
{
     FMDatabase *fmdb = [self instancetFMDB];
    
     FMResultSet *rs = [fmdb getTableSchema:tableName];
    NSMutableArray *titles = [NSMutableArray array];
    while ([rs next]) {
        NSString *title = [rs stringForColumn:@"name"];
        [titles addObject:title];
    }
  
    NSString *sqlStr = [NSString stringWithFormat:@"select * from %@ where %@='%@'",tableName.lowercaseString,key.lowercaseString,value.lowercaseString];
    FMResultSet *resultSet = [fmdb executeQuery:sqlStr];
//    FMResultSet *resultSet = [fmdb executeQueryWithFormat:@"select * from %@ where %@='%@'",tableName.lowercaseString,key.lowercaseString,value.lowercaseString];
     NSMutableArray *resultMuArray = [NSMutableArray array];
    while ([resultSet next]) {
        NSMutableDictionary *resultMuDic = [NSMutableDictionary dictionary];
        for (NSString *key in titles) {
            NSString *obj = [resultSet stringForColumn:key];
            if (obj) {
                [resultMuDic setObject:obj forKey:key];
            }
        }
        [resultMuArray addObject:[resultMuDic copy]];
    }
    [fmdb closeOpenResultSets];
    return  [resultMuArray copy];
}
/**
 检查字段
//添加新字段 alter table test1 add column field10 text;
 @param fmdb FMDatabase对象
 @param tableName 表名
 @param keys 需要检查字段的数组
 @return YES:对字段操作成功，如有新的字段则添加字段，如没有就直接返回YES;NO:检查操作失败
 */
- (BOOL)checkCondition:(FMDatabase*)fmdb andTableName:(NSString*)tableName andCondition: (NSArray*)keys
{
        NSString *sqlstr = [NSString stringWithFormat:@"select * from %@",[tableName lowercaseString]];
        FMResultSet *result = [fmdb executeQuery:sqlstr];
        if (result == nil) {
            NSLog(@"没找到%@表",tableName);
            return NO;
        }
        NSMutableArray *newKeys = [NSMutableArray array];
        for (NSString *key in keys) {
    
            if (![fmdb columnExists:key inTableWithName:tableName]) {
                [newKeys addObject:key];
            }
        }
    
        //当有新的字段产生时，先在表中添加新的字段
        if (newKeys.count) {
    
            NSString *fieldStr = @"";
            for ( int i =0;i<newKeys.count; i++) {
    
                NSString *newKey = newKeys[i];
                newKey = [newKey lowercaseString];
    
                NSString *columnStr = [NSString stringWithFormat:@"add column %@ text",newKey];
                fieldStr = [fieldStr stringByAppendingString:columnStr];
                NSString *alertsql = [NSString stringWithFormat:@"alter table %@ %@;",tableName,fieldStr];
                BOOL isSuccess = [fmdb executeUpdate:alertsql];
                if (!isSuccess) {
                    NSLog(@"新增字段失败");
                    return NO;
                }
                fieldStr = @"";
            }
        }
    
    return YES;

}
//初始化数据
- (FMDatabase*)instancetFMDB
{
    static FMDatabase *fmdb ;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        NSString *documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
        NSString *databasePath = [documentsPath stringByAppendingPathComponent:DBPath];
        NSLog(@"dbPaht:%@",databasePath);
        fmdb = [FMDatabase databaseWithPath:databasePath];
    });
    
    return fmdb;
}
//打开数据库
- (BOOL)open
{
    FMDatabase *fmdb = [self instancetFMDB];
    return [fmdb open];
}
//关闭数据库
-(BOOL)close
{
    FMDatabase *fmdb = [self instancetFMDB];
    return [fmdb close];
}
@end
