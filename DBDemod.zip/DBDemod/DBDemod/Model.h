//
//  Model.h
//  DBDemod
//
//  Created by hzjava-imac on 2017/3/3.
//  Copyright © 2017年 hzjava-imac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Model : NSObject

@property (nonatomic,strong) NSString *name;

@property (nonatomic,strong) NSString *ID;

@property (nonatomic,strong) NSString *age;
@end
